echo "Starting perf test"

#Read user input
echo "Please enter thread count"
read threadCount

echo "Please enter ramp up period in seconds"
read rampUpPeriodInSec

echo "Please enter loop count (enter '-1' for infinite)"
read loopCount

#read duration if loopcount is infinite ('-1')
if [ $loopCount -eq -1 ]
then
    echo "Please enter execution duration in seconds"
	read duration
else
    echo "Setting duration as (x * rampUpPeriodInSec * loopCount)"
	duration=$((10 * $rampUpPeriodInSec * $loopCount))
fi


echo "Please enter execution environment (ex: local, staging, prod)"
read environment

echo "Please enter jmx filename (ex: './get-course/getCourse.jmx')"
echo "----  Available jmx scripts  ----"
echo "./audit-log/auditLog.jmx"
echo "./get-course/getCourse.jmx"
echo "./lesson-details/lessonDetails.jmx"
echo "----  x  ----"
read jmeterScriptPath

#extract jmx script name from path
scrpitname="${jmeterScriptPath##*/}"
namewithoutjmx="${scrpitname%.jmx}"

#create output folder
foldername="./output/"$(date +%Y-%m-%d-%H%M%S)"-$environment-T$threadCount-R$rampUpPeriodInSec-L$loopCount-D$duration-$namewithoutjmx"
echo "Creating output direcoty: $foldername"
mkdir -p  "$foldername"

#Print execution command
echo "Execution configurations: "
echo "jmeter -Jthreads=$threadCount \\"
echo "-Jrampupperiod=$rampUpPeriodInSec \\"
echo "-Jloopcount=$loopCount \\"
echo "-Jduration=$duration \\"
echo "-Jenvironment=$environment \\"
echo "-n -t $jmeterScriptPath \\"
echo "-l $foldername/logs/result.csv \\"
echo "-e -o $foldername/report/"
echo "----  Started execution  ----"

#Run Jmeter command
jmeter -Jthreads=$threadCount \
-Jrampupperiod=$rampUpPeriodInSec \
-Jloopcount=$loopCount \
-Jduration=$duration \
-Jenvironment=$environment \
-n -t $jmeterScriptPath \
-l $foldername/logs/result.csv \
-e -o $foldername/report/

echo "Check reports in directory: $foldername"
echo "Press any key to exit"
read