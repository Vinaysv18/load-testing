# igot-perf-test


## Getting started

## Jmeter setup in ubuntu:
### Java install:
- sudo apt install default-jdk

### Jmeter download and setup:
- wget https://dlcdn.apache.org//jmeter/binaries/apache-jmeter-5.6.3.zip
- ls
- unzip apache-jmeter-5.6.3.zip
- mv apache-jmeter-5.6.3 jmeter
- sudo mv jmeter /opt
- echo 'export PATH="$PATH:/opt/jmeter/bin"' >> ~/.bashrc
- source ~/.bashrc
- jmeter


-unzip swayam-perf-test.zip


## Convert Windows line endings (CRLF) to Linux line endings (LF).
sudo apt-get install dos2unix
dos2unix run-perf-test-interactive.sh

## zip reports folder
zip -r output.zip output

## Jmeter setup in windows:
- Download Jmeter zip file and extract.
- Set environment path to ~/apache-jmeter-5.6.3/bin

## Jmeter perf test execution:
run run-perf-test-interactive.sh and follow the steps:

cmd>sh run-perf-test-interactive.sh
cmd>input required load parameters (Thread count/Ramp-up preriod/loopcount)

refer below table to trigger different load on required API.

Threads    Ramp-up period    loopcount    Duration (sec)
30         30                -1           300
50         30                -1           300
75         30                -1           300


## Report directory:
Report will be created in the output folder, prefixed with the execution timestamp.
ex: ./output/yyyy-mm-dd-hhmmss-local-T10-R10-L-1-D120-apiname/

## Generate report from logs if execution stopped without html report:
jmeter -g result.csv -o report